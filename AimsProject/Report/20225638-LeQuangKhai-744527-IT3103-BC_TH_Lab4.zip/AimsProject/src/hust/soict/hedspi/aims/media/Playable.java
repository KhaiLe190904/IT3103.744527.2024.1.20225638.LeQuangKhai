package hust.soict.hedspi.aims.media;
// Le Quang Khai - 20225638
public interface Playable {
    public void play();
}
