
package hust.soict.hedspi.aims.media;

import hust.soict.hedspi.aims.exception.PlayerException;
// Lê Quang Khải 20225638
public interface Playable {
	public void play() throws PlayerException;
}
